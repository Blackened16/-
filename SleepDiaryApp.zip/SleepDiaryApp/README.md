# Дневник сна — Android-проект

Готовый исходный код (Kotlin + WebView). В проекте намеренно нет
файла `gradle-wrapper.jar` — это бинарный файл, который нельзя
сгенерировать без доступа к интернету там, где создавался этот
проект. Ниже два рабочих способа собрать APK без него.

## Способ 1 — Android Studio (компьютер)

Так надёжнее всего, потому что Android Studio сам создаёт корректный
Gradle wrapper под установленную версию.

1. Создайте новый пустой проект: File → New Project → **Empty Views
   Activity** (Kotlin, Language: Kotlin).
2. Замените в новом проекте:
   - `app/src/main/java/.../MainActivity.kt` → на файл из этого архива
   - добавьте папку `app/src/main/assets/` и положите туда
     `sleep-diary.html` из этого архива
   - `app/src/main/AndroidManifest.xml` → возьмите блок `<application>`
     из этого архива (иконки и тема уже настроены)
   - скопируйте папки `mipmap-*` из `app/src/main/res/` этого архива
     в `res/` вашего нового проекта (замените стандартные)
3. Build → Build Bundle(s)/APK(s) → Build APK(s).

## Способ 2 — GitHub Actions (полностью с телефона, без Android Studio)

1. Создайте бесплатный аккаунт на github.com, если его нет.
2. Создайте новый repository и загрузите в него все файлы из этого
   архива, сохранив структуру папок (веб-интерфейс GitHub → Add file →
   Upload files; вложенные пути можно указывать прямо в имени файла
   при создании через "Create new file", например
   `app/src/main/assets/sleep-diary.html`).
3. Файл `.github/workflows/build.yml` уже настроен: он сам
   устанавливает Gradle в облаке (без wrapper) и собирает APK.
4. Вкладка **Actions** в репозитории → дождитесь зелёной галочки →
   откройте завершённый run → в разделе **Artifacts** скачайте
   `sleep-diary-debug-apk` — внутри готовый `app-debug.apk`.

Оба способа дают один и тот же результат — просто выберите
удобный вам.
