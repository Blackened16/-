package com.example.sleepdiary

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private val importRequestCode = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "Android")

        webView.loadUrl("file:///android_asset/sleep-diary.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun exportData(json: String) {
            runOnUiThread {
                try {
                    val dir = getExternalFilesDir(null)
                    val file = File(dir, "sleep-diary-backup.json")
                    file.writeText(json)
                    Toast.makeText(
                        this@MainActivity,
                        "Сохранено: ${file.absolutePath}",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Ошибка экспорта", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun requestImport() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "application/json"
                startActivityForResult(Intent.createChooser(intent, "Выберите файл бэкапа"), importRequestCode)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequestCode && resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                try {
                    val json = contentResolver.openInputStream(uri)
                        ?.bufferedReader()?.use { it.readText() } ?: ""
                    val escaped = json.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$")
                    webView.evaluateJavascript("window.importFromNative(`$escaped`)", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "Ошибка импорта", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
